<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NRW_CV_Shortcode {

    public function __construct() {
        add_shortcode( 'nrw_certificate_verify', array( $this, 'render_shortcode' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
    }

    public function enqueue_scripts() {
        global $post;
        if ( is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'nrw_certificate_verify' ) ) {
            wp_enqueue_style( 'nrw-cv-frontend-css', NRW_CV_PLUGIN_URL . 'assets/css/nrw-frontend.css', array(), NRW_CV_VERSION );
            wp_enqueue_script( 'nrw-cv-frontend-js', NRW_CV_PLUGIN_URL . 'assets/js/nrw-frontend.js', array( 'jquery' ), NRW_CV_VERSION, true );

            wp_localize_script( 'nrw-cv-frontend-js', 'nrw_cv_ajax', array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce'    => wp_create_nonce( 'nrw_cv_verify_nonce' )
            ) );
        }
    }

    public function render_shortcode() {
        ob_start();
        ?>
        <div class="nrw-cv-container">
            <div class="nrw-cv-card">
                <h2>Verify Certificate</h2>
                <form id="nrw-cv-verify-form">
                    <input type="text" id="nrw-cv-cert-id" placeholder="Enter Certificate ID" required>
                    <button type="submit" id="nrw-cv-btn">Verify</button>
                    <div class="nrw-cv-loader" style="display:none;">Loading...</div>
                </form>
                <div id="nrw-cv-result"></div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}