<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NRW_CV_Activator {

    public static function activate() {
        self::create_database_table();
        self::create_verification_page();
        self::set_default_options();
    }

    private static function create_database_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'nrw_certificates';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            student_name varchar(255) NOT NULL,
            certificate_id varchar(100) NOT NULL,
            course_name varchar(255) NOT NULL,
            organization varchar(255) NOT NULL,
            issue_date date NOT NULL,
            completion_date date,
            status varchar(50) DEFAULT 'valid',
            cert_url varchar(255),
            notes text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY certificate_id (certificate_id)
        ) $charset_collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );
    }

    private static function create_verification_page() {
        $page_title = 'Verify Certificate';
        $page_slug = 'verify';

        // Check if page already exists
        $page = get_page_by_path( $page_slug );
        if ( ! $page ) {
            $page_id = wp_insert_post( array(
                'post_title'     => $page_title,
                'post_name'      => $page_slug,
                'post_content'   => '[nrw_certificate_verify]',
                'post_status'    => 'publish',
                'post_type'      => 'page',
                'comment_status' => 'closed',
            ) );
            update_option( 'nrw_cv_verify_page_id', $page_id );
        }
    }

    private static function set_default_options() {
        if ( false === get_option( 'nrw_cv_cleanup_on_uninstall' ) ) {
            add_option( 'nrw_cv_cleanup_on_uninstall', 'no' );
        }
    }
}