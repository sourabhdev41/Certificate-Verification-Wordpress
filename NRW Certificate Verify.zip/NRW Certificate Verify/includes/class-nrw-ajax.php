<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NRW_CV_Ajax {

    public function __construct() {
        add_action( 'wp_ajax_verify_nrw_certificate', array( $this, 'verify_certificate' ) );
        add_action( 'wp_ajax_nopriv_verify_nrw_certificate', array( $this, 'verify_certificate' ) );
    }

    public function verify_certificate() {
        check_ajax_referer( 'nrw_cv_verify_nonce', 'nonce' );

        $cert_id = isset( $_POST['cert_id'] ) ? sanitize_text_field( wp_unslash( $_POST['cert_id'] ) ) : '';

        if ( empty( $cert_id ) ) {
            wp_send_json_error( 'Please enter a Certificate ID.' );
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'nrw_certificates';

        // Prepare statement to prevent SQL Injection
        $certificate = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $table_name WHERE certificate_id = %s",
            $cert_id
        ) );

        if ( $certificate ) {
            $data = array(
                'student_name'  => esc_html( $certificate->student_name ),
                'course_name'   => esc_html( $certificate->course_name ),
                'organization'  => esc_html( $certificate->organization ),
                'issue_date'    => esc_html( date( 'F j, Y', strtotime( $certificate->issue_date ) ) ),
                'status'        => esc_html( ucfirst( $certificate->status ) ),
            );
            wp_send_json_success( $data );
        } else {
            wp_send_json_error( 'Certificate ID not found. This certificate may be invalid or incorrect.' );
        }
    }
}