<?php
// If uninstall is not called from WordPress, exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Check if cleanup is enabled in settings
$cleanup_enabled = get_option( 'nrw_cv_cleanup_on_uninstall' );

if ( 'yes' === $cleanup_enabled ) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'nrw_certificates';

    // Remove Database Table
    $wpdb->query( "DROP TABLE IF EXISTS $table_name" );

    // Remove Settings
    delete_option( 'nrw_cv_cleanup_on_uninstall' );
    delete_option( 'nrw_cv_verify_page_id' );
    
    // (Optional) Remove the generated WordPress page if you wish
    // $page_id = get_option('nrw_cv_verify_page_id');
    // if ($page_id) { wp_delete_post($page_id, true); }
}