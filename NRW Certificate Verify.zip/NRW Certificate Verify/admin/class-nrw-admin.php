<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NRW_CV_Admin {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_plugin_admin_menu' ) );
    }

    public function add_plugin_admin_menu() {
        add_menu_page(
            'NRW Certificate Verify', 
            'Certificate Verify', 
            'manage_options', 
            'nrw-certificate-verify', 
            array( $this, 'display_plugin_admin_page' ), 
            'dashicons-awards', 
            25 
        );

        add_submenu_page(
            'nrw-certificate-verify',
            'Settings',
            'Settings',
            'manage_options',
            'nrw-certificate-settings',
            array( $this, 'display_settings_page' )
        );
    }

    public function display_plugin_admin_page() {
        // Here is where you will initialize your WP_List_Table for Certificates
        echo '<div class="wrap">';
        echo '<h1>NRW Certificates Dashboard</h1>';
        echo '<p>Admin UI and WP_List_Table rendering goes here.</p>';
        echo '</div>';
    }

    public function display_settings_page() {
        echo '<div class="wrap">';
        echo '<h1>Settings</h1>';
        echo '<p>Settings fields (Page Slug, Clean Uninstall, etc.) go here.</p>';
        echo '</div>';
    }
}