<?php
/**
 * Plugin Name:       NRW Certificate Verify
 * Plugin URI:        https://wp.nrwone.in
 * Description:       A modern certificate verification system for WordPress.
 * Version:           1.0.0
 * Author:            NRW India
 * Author URI:        https://wp.nrwone.in
 * Text Domain:       nrw-certificate-verify
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

define( 'NRW_CV_VERSION', '1.0.0' );
define( 'NRW_CV_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'NRW_CV_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Include necessary classes
require_once NRW_CV_PLUGIN_DIR . 'includes/class-nrw-activator.php';
require_once NRW_CV_PLUGIN_DIR . 'includes/class-nrw-shortcode.php';
require_once NRW_CV_PLUGIN_DIR . 'includes/class-nrw-ajax.php';
require_once NRW_CV_PLUGIN_DIR . 'admin/class-nrw-admin.php';

// Activation Hook
register_activation_hook( __FILE__, array( 'NRW_CV_Activator', 'activate' ) );

// Initialize Plugin
function run_nrw_certificate_verify() {
    new NRW_CV_Shortcode();
    new NRW_CV_Ajax();
    if ( is_admin() ) {
        new NRW_CV_Admin();
    }
}
add_action( 'plugins_loaded', 'run_nrw_certificate_verify' );